# MurdochOverlay
Firefox extension that adds an overlay to Murdoch owned "news" sites.
